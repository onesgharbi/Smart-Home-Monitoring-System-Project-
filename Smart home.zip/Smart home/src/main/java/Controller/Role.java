package Controller;


public enum Role {
    HOMEOWNER,
    TECHNICIAN,
    SECURITY_GUARD
}

