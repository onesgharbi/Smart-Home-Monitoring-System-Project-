package models;



public enum Role {
    HOMEOWNER,
    TECHNICIAN,
    SECURITY_GUARD
}
